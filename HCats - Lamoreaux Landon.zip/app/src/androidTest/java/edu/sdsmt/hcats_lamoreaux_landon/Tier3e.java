package edu.sdsmt.hcats_lamoreaux_landon;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.platform.app.InstrumentationRegistry.getInstrumentation;
import static org.junit.Assert.assertEquals;

import android.content.pm.ActivityInfo;
import android.widget.Button;
import android.widget.TextView;

import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import java.util.concurrent.atomic.AtomicReference;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(AndroidJUnit4.class)
public class Tier3e {
    @Rule
    public ActivityScenarioRule<MainActivity> act = new ActivityScenarioRule<>(MainActivity.class);

    private Game g;
    private StateMachine sm;
    private MainActivity mainAct;
    private Button treatBtn;
    private Button resetBtn;
    private Button downBtn;
    private Button rightBtn;
    private TextView treatView;
    private TextView moveView;
    private TextView caughtView;

    //Initialize to have access to underlying game, state machine, and buttons
    private void init(){
        AtomicReference<Game> gameAtom = new AtomicReference<>();
        AtomicReference<StateMachine> smAtom = new AtomicReference<>();
        AtomicReference<Button> treatBtnAtom = new AtomicReference<>();
        AtomicReference<Button> resetBtnAtom = new AtomicReference<>();
        AtomicReference<Button> downBtnAtom = new AtomicReference<>();
        AtomicReference<Button> rightBtnAtom = new AtomicReference<>();
        AtomicReference<TextView> treatAtom = new AtomicReference<>();
        AtomicReference<TextView> moveAtom = new AtomicReference<>();
        AtomicReference<TextView> caughtAtom = new AtomicReference<>();
        act.getScenario().onActivity(act -> {
            mainAct = act;
            gameAtom.set(act.getGame());
            smAtom.set(act.getStateMachine());

            treatBtnAtom.set(act.findViewById(R.id.treatBtn));
            resetBtnAtom.set(act.findViewById(R.id.resetBtn));
            downBtnAtom.set(act.findViewById(R.id.downBtn));
            rightBtnAtom.set(act.findViewById(R.id.rightBtn));

            treatAtom.set(act.findViewById(R.id.treats));
            moveAtom.set(act.findViewById(R.id.moves));
            caughtAtom.set(act.findViewById(R.id.caught));
        });

        g = gameAtom.get();
        sm = smAtom.get();
        treatBtn=treatBtnAtom.get();
        resetBtn=resetBtnAtom.get();
        downBtn=downBtnAtom.get();
        rightBtn=rightBtnAtom.get();

        treatView = treatAtom.get();
        moveView = moveAtom.get();
        caughtView = caughtAtom.get();
    }

    @Test
    public void a_checkRotate() {
        init();
        onView(withId(R.id.rightBtn)).perform(click());
        onView(withId(R.id.rightBtn)).perform(click());
        onView(withId(R.id.downBtn)).perform(click());
        onView(withId(R.id.treatBtn)).perform(click());

        // Row 1
        assertEquals(0,  g.getCatsAt(0, 0));
        assertEquals(1,  g.getCatsAt(1, 0));
        assertEquals(6,  g.getCatsAt(2, 0));
        // Row 2
        assertEquals(0,  g.getCatsAt(0, 1));
        assertEquals(4,  g.getCatsAt(1, 1));
        assertEquals(11,  g.getCatsAt(2, 1));
        // Row 3
        assertEquals(0,  g.getCatsAt(0, 2));
        assertEquals(7,  g.getCatsAt(1, 2));
        // Check caught count.
        assertEquals(11,  g.getCatsCaught());

        assertEquals(2, Integer.parseInt(treatView.getText().toString()));
        assertEquals(11, Integer.parseInt(moveView.getText().toString()));
        assertEquals(11, Integer.parseInt(caughtView.getText().toString()));

        mainAct.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        getInstrumentation().waitForIdleSync();

        init();

        // Row 1
        assertEquals(0,  g.getCatsAt(0, 0));
        assertEquals(1,  g.getCatsAt(1, 0));
        assertEquals(6,  g.getCatsAt(2, 0));
        // Row 2
        assertEquals(0,  g.getCatsAt(0, 1));
        assertEquals(4,  g.getCatsAt(1, 1));
        assertEquals(11,  g.getCatsAt(2, 1));
        // Row 3
        assertEquals(0,  g.getCatsAt(0, 2));
        assertEquals(7,  g.getCatsAt(1, 2));
        // Check caught count.
        assertEquals(11,  g.getCatsCaught());

        assertEquals(2, Integer.parseInt(treatView.getText().toString()));
        assertEquals(11, Integer.parseInt(moveView.getText().toString()));
        assertEquals(11, Integer.parseInt(caughtView.getText().toString()));
    }
}
